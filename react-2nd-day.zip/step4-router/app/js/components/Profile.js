import React from 'react';

const Profile = (props) => {
        return ( < div > Profile Page { props.name } < /div>);
        }

        export default Profile;
