import React from 'react';

const Home = (props) => {
    return ( < div > This is home page < /div>);
}

export default Home;
