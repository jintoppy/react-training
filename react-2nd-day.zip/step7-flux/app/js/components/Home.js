import React from 'react';
import UserStore from '../stores/UserStore';

class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            users: UserStore.getUsers()
        };
    }
    render() {
    	var returnData;
    	if(this.state.users.length>0){
    		var rows = this.state.users.map(function(user){
	    		return (
	    				<tr>
	    					<td>{user.name}</td>
	    					<td>{user.age}</td>
	    				</tr>
	    			)
	    	});	

	    	returnData = (
	    			<table>
	    				<thead>
	    					<tr>Name</tr>
	    					<tr>Age</tr>
	    				</thead>
	    				<tbody>
	    					{rows}
	    				</tbody>
	    			</table>
	    		)
    	}
    	else{
    		returnData = (<span>No Users</span>)
    	}
    	

    	return (<div>
    			{returnData}
    		</div>)

    }
}

export default Home;
